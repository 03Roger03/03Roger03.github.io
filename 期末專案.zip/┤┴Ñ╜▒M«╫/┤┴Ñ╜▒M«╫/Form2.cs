﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 期末專案
{
    public partial class Form2 : Form
    {
        Form6 f6; 
        Form4 f4;
        Form5 f5;
        public Form2()
        {
            InitializeComponent();
            f6 = new Form6();
            f4 = new Form4();
            f5 = new Form5();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            f6.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            f4.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            f5.Visible = true;
        }
    }
}
