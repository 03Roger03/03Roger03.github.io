﻿namespace 期末專案
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.btnRefuel = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.chkFullTank = new System.Windows.Forms.CheckBox();
            this.chkRandom = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtLiters = new System.Windows.Forms.TextBox();
            this.txtPricePerLiter = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.timerRefuel = new System.Windows.Forms.Timer(this.components);
            this.lblCurrentLiters = new System.Windows.Forms.Label();
            this.lblCurrentTotalPrice = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnRefuel
            // 
            this.btnRefuel.Font = new System.Drawing.Font("新細明體", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnRefuel.Location = new System.Drawing.Point(186, 312);
            this.btnRefuel.Name = "btnRefuel";
            this.btnRefuel.Size = new System.Drawing.Size(178, 89);
            this.btnRefuel.TabIndex = 0;
            this.btnRefuel.Text = "加油";
            this.btnRefuel.UseVisualStyleBackColor = true;
            this.btnRefuel.Click += new System.EventHandler(this.btnRefuel_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("新細明體", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button2.Location = new System.Drawing.Point(404, 312);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(170, 86);
            this.button2.TabIndex = 1;
            this.button2.Text = "停止";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // chkFullTank
            // 
            this.chkFullTank.AutoSize = true;
            this.chkFullTank.Location = new System.Drawing.Point(191, 323);
            this.chkFullTank.Name = "chkFullTank";
            this.chkFullTank.Size = new System.Drawing.Size(59, 19);
            this.chkFullTank.TabIndex = 2;
            this.chkFullTank.Text = "加滿";
            this.chkFullTank.UseVisualStyleBackColor = true;
            this.chkFullTank.CheckedChanged += new System.EventHandler(this.chkFullTank_CheckedChanged);
            // 
            // chkRandom
            // 
            this.chkRandom.AutoSize = true;
            this.chkRandom.Location = new System.Drawing.Point(194, 377);
            this.chkRandom.Name = "chkRandom";
            this.chkRandom.Size = new System.Drawing.Size(59, 19);
            this.chkRandom.TabIndex = 3;
            this.chkRandom.Text = "隨機";
            this.chkRandom.UseVisualStyleBackColor = true;
            this.chkRandom.CheckedChanged += new System.EventHandler(this.chkRandom_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(178, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 47);
            this.label1.TabIndex = 4;
            this.label1.Text = "公升:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(178, 174);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 47);
            this.label2.TabIndex = 5;
            this.label2.Text = "油錢:";
            // 
            // txtLiters
            // 
            this.txtLiters.Font = new System.Drawing.Font("新細明體", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtLiters.Location = new System.Drawing.Point(346, 93);
            this.txtLiters.Name = "txtLiters";
            this.txtLiters.Size = new System.Drawing.Size(159, 52);
            this.txtLiters.TabIndex = 6;
            // 
            // txtPricePerLiter
            // 
            this.txtPricePerLiter.Font = new System.Drawing.Font("新細明體", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtPricePerLiter.Location = new System.Drawing.Point(346, 169);
            this.txtPricePerLiter.Name = "txtPricePerLiter";
            this.txtPricePerLiter.Size = new System.Drawing.Size(159, 52);
            this.txtPricePerLiter.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(220, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(285, 47);
            this.label3.TabIndex = 8;
            this.label3.Text = "一公升29.3元";
            // 
            // timerRefuel
            // 
            this.timerRefuel.Tick += new System.EventHandler(this.timerRefuel_Tick);
            // 
            // lblCurrentLiters
            // 
            this.lblCurrentLiters.AutoSize = true;
            this.lblCurrentLiters.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCurrentLiters.Location = new System.Drawing.Point(499, 42);
            this.lblCurrentLiters.Name = "lblCurrentLiters";
            this.lblCurrentLiters.Size = new System.Drawing.Size(27, 30);
            this.lblCurrentLiters.TabIndex = 9;
            this.lblCurrentLiters.Text = "0";
            // 
            // lblCurrentTotalPrice
            // 
            this.lblCurrentTotalPrice.AutoSize = true;
            this.lblCurrentTotalPrice.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCurrentTotalPrice.Location = new System.Drawing.Point(511, 93);
            this.lblCurrentTotalPrice.Name = "lblCurrentTotalPrice";
            this.lblCurrentTotalPrice.Size = new System.Drawing.Size(76, 30);
            this.lblCurrentTotalPrice.TabIndex = 10;
            this.lblCurrentTotalPrice.Text = "$0.00";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblCurrentTotalPrice);
            this.Controls.Add(this.lblCurrentLiters);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtPricePerLiter);
            this.Controls.Add(this.txtLiters);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.chkRandom);
            this.Controls.Add(this.chkFullTank);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnRefuel);
            this.Name = "Form3";
            this.Text = "92無鉛汽油";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRefuel;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.CheckBox chkFullTank;
        private System.Windows.Forms.CheckBox chkRandom;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtLiters;
        private System.Windows.Forms.TextBox txtPricePerLiter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Timer timerRefuel;
        private System.Windows.Forms.Label lblCurrentLiters;
        private System.Windows.Forms.Label lblCurrentTotalPrice;
    }
}