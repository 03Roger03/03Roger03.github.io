﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 期末專案
{
    public partial class Form4 : Form
    {
        private decimal targetLiters;
        private decimal currentLiters;
        private decimal pricePerLiter;
        private decimal currentTotalPrice;
        private bool isRandom;
        private bool isStopping;
        private EventHandler btnStop_Click;
  

        public EventHandler TimerRefuel_Tick { get; private set; }
 

        public Form4()
        {
            InitializeComponent();
            chkFullTank.CheckedChanged += chkFullTank_CheckedChanged;
            chkRandom.CheckedChanged += chkRandom_CheckedChanged;
            btnRefuel.Click += btnRefuel_Click;
            btnStop.Click += btnStop_Click;

            // 設定計時器間隔和Tick事件
            timerRefuel.Interval = 100; // 設定計時器間隔為100毫秒
            timerRefuel.Tick += TimerRefuel_Tick;
     
        }

        private void chkFullTank_CheckedChanged(object sender, EventArgs e)
        {
            if (chkFullTank.Checked)
            {
                chkRandom.Checked = false;
                txtLiters.Enabled = true;
                isRandom = false;
            }
        }

        private void chkRandom_CheckedChanged(object sender, EventArgs e)
        {
            if (chkRandom.Checked)
            {
                chkFullTank.Checked = false;
                txtLiters.Enabled = false;
                isRandom = true;
            }
        }

        private void btnRefuel_Click(object sender, EventArgs e)
        {
            if (isRandom)
            {
                currentLiters = 0m;
                currentTotalPrice = 0m;
                isStopping = false;
                timerRefuel.Interval = 100;
                pricePerLiter = decimal.TryParse(txtPricePerLiter.Text, out decimal price) ? price : 0m;
                timerRefuel.Start();
            }
            else
            {
                // 加滿模式
                if (decimal.TryParse(txtLiters.Text, out targetLiters) && decimal.TryParse(txtPricePerLiter.Text, out pricePerLiter))
                {
                    if (targetLiters <= 0)
                    {
                        MessageBox.Show("公升數必須大於0。");
                        return;
                    }

                    if (pricePerLiter <= 0)
                    {
                        MessageBox.Show("油價必須大於0。");
                        return;
                    }

                    currentLiters = 0m;
                    currentTotalPrice = 0m;
                    isStopping = false;
                    timerRefuel.Interval = 100;
                    timerRefuel.Start();
                }
                else
                {
                    MessageBox.Show("請輸入有效的公升數和油價。");
                }
            }
        }
        private void timerRefuel_Tick(object sender, EventArgs e)
        {
            if (isRandom)
            {
                currentLiters += 0.1m; // 每次增加0.1公升
                currentTotalPrice += pricePerLiter * 0.1m; // 每次增加0.1公升的價格
                lblCurrentLiters.Text = currentLiters.ToString("0.0");
                lblCurrentTotalPrice.Text = currentTotalPrice.ToString("C");
            }
            else
            {
                if (currentLiters < targetLiters)
                {
                    currentLiters += 0.1m; // 每次增加0.1公升
                    if (currentLiters > targetLiters)
                    {
                        currentLiters = targetLiters; // 避免超過目標公升數
                    }
                    currentTotalPrice = currentLiters * pricePerLiter; // 公升乘油價的計算
                    lblCurrentLiters.Text = currentLiters.ToString("0.0");
                    lblCurrentTotalPrice.Text = currentTotalPrice.ToString("C");
                }
                else
                {
                    timerRefuel.Stop();
                }
            }


        }
        private void BtnStop_Click(object sender, EventArgs e)
        {
            if (isRandom)
            {
                if (isStopping)
                {
                    timerRefuel.Stop(); // 完全停止
                }
                else
                {
                    timerRefuel.Interval *= 2; // 減緩速度到一半
                    isStopping = true;
                }
            }
            else
            {
                timerRefuel.Stop();
            }
        }
        }
    }

