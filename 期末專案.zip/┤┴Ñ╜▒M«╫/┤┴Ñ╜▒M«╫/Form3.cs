﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 期末專案
{
    public partial class Form3 : Form
    {
        private int targetLiters;
        private int currentLiters;
        private decimal pricePerLiter;
        private decimal currentTotalPrice;
        public Form3()
        {
            InitializeComponent();
            timerRefuel.Interval = 100; // 設定計時器間隔為100毫秒
            timerRefuel.Tick += TimerRefuel_Tick;
            InitializeComponent();
        }

        public EventHandler TimerRefuel_Tick { get; }

  

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void timerRefuel_Tick(object sender, EventArgs e)
        {
            if (currentLiters < targetLiters)
            {
                currentLiters++;
                currentTotalPrice = currentLiters * pricePerLiter;
                lblCurrentLiters.Text = currentLiters.ToString();
                lblCurrentTotalPrice.Text = currentTotalPrice.ToString("C");
            }
            else
            {
                timerRefuel.Stop();
            }
        }

        private void chkFullTank_CheckedChanged(object sender, EventArgs e)
        {
            if (chkFullTank.Checked)
            {
                chkRandom.Checked = false;
                txtLiters.Enabled = true;
            }
        }

        private void chkRandom_CheckedChanged(object sender, EventArgs e)
        {
            if (chkRandom.Checked)
            {
                chkFullTank.Checked = false;
                txtLiters.Enabled = false;
            }
        }

        private void btnRefuel_Click(object sender, EventArgs e)
        {
            if (chkFullTank.Checked && int.TryParse(txtLiters.Text, out targetLiters) && decimal.TryParse(txtPricePerLiter.Text, out pricePerLiter))
            {
                // 檢查輸入的值是否有效
                if (targetLiters <= 0)
                {
                    MessageBox.Show("公升數必須大於0。");
                    return;
                }

                if (pricePerLiter <= 0)
                {
                    MessageBox.Show("油價必須大於0。");
                    return;
                }

                // 初始化加油過程
                currentLiters = 0;
                currentTotalPrice = 0m;
                timerRefuel.Start();
            }
            else
            {
                MessageBox.Show("請輸入有效的公升數和油價。");
            }
        }
    }
}
