﻿namespace 期末專案
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form6));
            this.lblCurrentTotalPrice = new System.Windows.Forms.Label();
            this.lblCurrentLiters = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPricePerLiter = new System.Windows.Forms.TextBox();
            this.txtLiters = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.chkFullTank = new System.Windows.Forms.CheckBox();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnRefuel = new System.Windows.Forms.Button();
            this.chkRandom = new System.Windows.Forms.CheckBox();
            this.timerRefuel = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // lblCurrentTotalPrice
            // 
            this.lblCurrentTotalPrice.AutoSize = true;
            this.lblCurrentTotalPrice.Font = new System.Drawing.Font("新細明體", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCurrentTotalPrice.Location = new System.Drawing.Point(495, 176);
            this.lblCurrentTotalPrice.Name = "lblCurrentTotalPrice";
            this.lblCurrentTotalPrice.Size = new System.Drawing.Size(151, 60);
            this.lblCurrentTotalPrice.TabIndex = 31;
            this.lblCurrentTotalPrice.Text = "$0.00";
            // 
            // lblCurrentLiters
            // 
            this.lblCurrentLiters.AutoSize = true;
            this.lblCurrentLiters.Font = new System.Drawing.Font("新細明體", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCurrentLiters.Location = new System.Drawing.Point(525, 105);
            this.lblCurrentLiters.Name = "lblCurrentLiters";
            this.lblCurrentLiters.Size = new System.Drawing.Size(53, 60);
            this.lblCurrentLiters.TabIndex = 30;
            this.lblCurrentLiters.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(197, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(285, 47);
            this.label3.TabIndex = 29;
            this.label3.Text = "一公升29.2元";
            // 
            // txtPricePerLiter
            // 
            this.txtPricePerLiter.Font = new System.Drawing.Font("新細明體", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtPricePerLiter.Location = new System.Drawing.Point(296, 181);
            this.txtPricePerLiter.Name = "txtPricePerLiter";
            this.txtPricePerLiter.Size = new System.Drawing.Size(159, 52);
            this.txtPricePerLiter.TabIndex = 28;
            this.txtPricePerLiter.Text = "29.2";
            // 
            // txtLiters
            // 
            this.txtLiters.Font = new System.Drawing.Font("新細明體", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtLiters.Location = new System.Drawing.Point(287, 105);
            this.txtLiters.Name = "txtLiters";
            this.txtLiters.Size = new System.Drawing.Size(159, 52);
            this.txtLiters.TabIndex = 27;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(155, 186);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 47);
            this.label2.TabIndex = 26;
            this.label2.Text = "油錢:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(155, 105);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 47);
            this.label1.TabIndex = 25;
            this.label1.Text = "公升:";
            // 
            // chkFullTank
            // 
            this.chkFullTank.AutoSize = true;
            this.chkFullTank.Location = new System.Drawing.Point(168, 335);
            this.chkFullTank.Name = "chkFullTank";
            this.chkFullTank.Size = new System.Drawing.Size(59, 19);
            this.chkFullTank.TabIndex = 24;
            this.chkFullTank.Text = "加滿";
            this.chkFullTank.UseVisualStyleBackColor = true;
            this.chkFullTank.CheckedChanged += new System.EventHandler(this.chkFullTank_CheckedChanged);
            // 
            // btnStop
            // 
            this.btnStop.Font = new System.Drawing.Font("新細明體", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnStop.Location = new System.Drawing.Point(381, 324);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(170, 86);
            this.btnStop.TabIndex = 23;
            this.btnStop.Text = "停止";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.BtnStop_Click);
            // 
            // btnRefuel
            // 
            this.btnRefuel.Font = new System.Drawing.Font("新細明體", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnRefuel.Location = new System.Drawing.Point(163, 324);
            this.btnRefuel.Name = "btnRefuel";
            this.btnRefuel.Size = new System.Drawing.Size(178, 89);
            this.btnRefuel.TabIndex = 22;
            this.btnRefuel.Text = "加油";
            this.btnRefuel.UseVisualStyleBackColor = true;
            this.btnRefuel.Click += new System.EventHandler(this.btnRefuel_Click);
            // 
            // chkRandom
            // 
            this.chkRandom.AutoSize = true;
            this.chkRandom.Location = new System.Drawing.Point(168, 391);
            this.chkRandom.Name = "chkRandom";
            this.chkRandom.Size = new System.Drawing.Size(59, 19);
            this.chkRandom.TabIndex = 32;
            this.chkRandom.Text = "隨機";
            this.chkRandom.UseVisualStyleBackColor = true;
            this.chkRandom.CheckedChanged += new System.EventHandler(this.chkRandom_CheckedChanged);
            // 
            // timerRefuel
            // 
            this.timerRefuel.Tick += new System.EventHandler(this.timerRefuel_Tick);
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.chkRandom);
            this.Controls.Add(this.lblCurrentTotalPrice);
            this.Controls.Add(this.lblCurrentLiters);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtPricePerLiter);
            this.Controls.Add(this.txtLiters);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.chkFullTank);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnRefuel);
            this.Name = "Form6";
            this.Text = "92無鉛汽油";
            this.Load += new System.EventHandler(this.Form6_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCurrentTotalPrice;
        private System.Windows.Forms.Label lblCurrentLiters;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPricePerLiter;
        private System.Windows.Forms.TextBox txtLiters;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chkFullTank;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnRefuel;
        private System.Windows.Forms.CheckBox chkRandom;
        private System.Windows.Forms.Timer timerRefuel;
    }
}