﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 期末專案
{
    public partial class 加油站 : Form
    {
        Form2 f2;
        public 加油站()
        {
            InitializeComponent();
            f2 = new Form2();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            f2.Visible = true;
        }

        private void 加油站_Load(object sender, EventArgs e)
        {

        }
    }
}
